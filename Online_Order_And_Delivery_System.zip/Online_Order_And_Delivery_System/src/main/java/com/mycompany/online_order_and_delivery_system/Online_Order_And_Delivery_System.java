/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.online_order_and_delivery_system;

/**
 *
 * @author kali-i
 */
public class Online_Order_And_Delivery_System {

    public static void main(String[] args) {
       Welcome aw=new Welcome();
       aw.show();
      
//      adminFiledata a=new adminFiledata();
//     
//       String aa[]=a.fetchDataById(1);
//      System.out.println(aa[2]);
//      
      
    }
}
