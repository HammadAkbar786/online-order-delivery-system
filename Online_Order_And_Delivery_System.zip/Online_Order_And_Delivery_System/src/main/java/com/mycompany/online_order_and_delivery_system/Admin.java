/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.online_order_and_delivery_system;

public class Admin {
    private int id;
    private String password;
    private String name;
    
    // Constructor method
    public Admin(int id, String password, String name) {
        this.id = id;
        this.password = password;
        this.name = name;
    }
    
    // Getter methods
    public int getId() {
        return id;
    }
    
    public String getPassword() {
        return password;
    }
    
    public String getName() {
        return name;
    }
    
    // Setter methods
    public void setId(int id) {
        this.id = id;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public void setName(String name) {
        this.name = name;
    }
}
