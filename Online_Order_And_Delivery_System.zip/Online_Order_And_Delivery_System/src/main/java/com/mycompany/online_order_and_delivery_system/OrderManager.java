/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.online_order_and_delivery_system;

import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;

public class OrderManager {
   private static final String FILE_NAME = "orders.txt";
   private static final String DELIMITER = ",";
   
    public void addOrder(int orderId, int customerId, String itemName, double price, String status, String staff) {
      try {
         BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true));
         String order = orderId + DELIMITER + customerId + DELIMITER + itemName + DELIMITER + price + DELIMITER + status + DELIMITER + staff;
         writer.write(order);
         writer.newLine();
         writer.close();
    JOptionPane.showMessageDialog(null, "Order Added to Cart");
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   }
    
  public void updateOrder(int orderId, int customerId, String itemName, double price, String status, String staff) {
      try {
         BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
         String line;
         String newFileContent = "";
         boolean found = false;
         
         while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(DELIMITER);
            
            if (Integer.parseInt(tokens[0]) == orderId) {
               found = true;
               line = orderId + DELIMITER + customerId + DELIMITER + itemName + DELIMITER + price + DELIMITER + status + DELIMITER + staff;
            }
            
            newFileContent += line + "\n";
         }
         
         reader.close();
         
         if (!found) {
    JOptionPane.showMessageDialog(null, "Order Not Found");
            return;
         }
         
         BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME));
         writer.write(newFileContent);
         writer.close();
    JOptionPane.showMessageDialog(null, "Order Updated Successfully");
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   }
   
 public void deleteOrder(int orderId) {
      try {
         BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
         String line;
         String newFileContent = "";
         boolean found = false;
         
         while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(DELIMITER);
            
            if (Integer.parseInt(tokens[0]) != orderId) {
               newFileContent += line + "\n";
            } else {
               found = true;
            }
         }
         
         reader.close();
         
         if (!found) {
    JOptionPane.showMessageDialog(null, "Order Not Found");
            return;
         }
         
         BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME));
         writer.write(newFileContent);
         writer.close();
             JOptionPane.showMessageDialog(null, "Order Deleted Successfully");
        
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   }
   
   public Order fetchOrder(int orderId) {
      Order o = null;
       try {
         BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
         String line;
         boolean found = false;
         
         while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(DELIMITER);
            
            if (Integer.parseInt(tokens[0]) == orderId) {
               found = true;
               o=new Order(Integer.parseInt(tokens[0]),Integer.parseInt(tokens[1]),tokens[2],(int)Double.parseDouble(tokens[3]),tokens[4],tokens[5]);
               break;
            }
         }
         
         reader.close();
         
         if (!found) {
            System.out.println("Order not found.");
         }
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   return o;
   }
   
   
   
      public ArrayList<String> fetchAllOrder(int custId) {
               ArrayList<String> data = new ArrayList<String>();
          try {
         BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
         String line;
         String d = "";
         
         while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(DELIMITER);
            
            if (Integer.parseInt(tokens[1]) == custId) {

               d+=tokens[0]+" \t";
               d+=tokens[1]+" \t";
               d+=tokens[2]+" \t";
               d+=tokens[3]+" \t";
               d+=tokens[4]+" \t";
               d+=tokens[5]+" \n";
               
               data.add(d);
               d="";
              
            }
         }
         
         reader.close();
         
       
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   return data;
}
    
public void UpdateorderStatus(int orderId) {
      try {
         BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
         String line;
         Order a;
         boolean found = false;
         
         while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(DELIMITER);
            
            if (Integer.parseInt(tokens[0]) == orderId) {
               found = true;
               a=new Order(Integer.parseInt(tokens[0]),Integer.parseInt(tokens[1]),tokens[2],(int)Double.parseDouble(tokens[3]),tokens[4],tokens[5]);
               this.updateOrder(a.getOrderId(), a.getCustomerId(), a.getItemName(), a.getPrice(), "Paid",a.getStaff());
           
            }
         }
         
         reader.close();
         
         if (!found) {
    JOptionPane.showMessageDialog(null, "Order Not Found");
         }
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   }

   public ArrayList<String> fetchAll() {
               ArrayList<String> data = new ArrayList<String>();
          try {
         BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
         String line;
         String d = "";
         
         while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(DELIMITER);
               d+=tokens[0]+" \t";
               d+=tokens[1]+" \t";
               d+=tokens[2]+" \t";
               d+=tokens[3]+" \t";
               d+=tokens[4]+" \t";
               d+=tokens[5]+" \n";
               
               data.add(d);
               d="";
              
            
         }
         
         reader.close();
         
       
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   return data;
}

      public ArrayList<String> fetchAllPaid() {
               ArrayList<String> data = new ArrayList<String>();
          try {
         BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
         String line;
         String d = "";
         
         while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(DELIMITER);
           
            if("paid".equals(tokens[4])||"Paid".equals(tokens[4])){
               d+=tokens[0]+" \t";
               d+=tokens[1]+" \t";
               d+=tokens[2]+" \t";
               d+=tokens[3]+" \t";
               d+=tokens[4]+" \t";
               d+=tokens[5]+" \n";
               
               data.add(d);
               d="";
              
            }
         }
         
         reader.close();
         
       
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   return data;
}
      
            public ArrayList<String> fetchAllNA(String na) {
               ArrayList<String> data = new ArrayList<String>();
          try {
         BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
         String line;
         String d = "";
         
         while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(DELIMITER);
           
            if("NA".equals(tokens[5])||"na".equals(tokens[5]) || na.equals(tokens[5])){
               d+=tokens[0]+" \t";
               d+=tokens[1]+" \t";
               d+=tokens[2]+" \t";
               d+=tokens[3]+" \t";
               d+=tokens[4]+" \t";
               d+=tokens[5]+" \n";
               
               data.add(d);
               d="";
              
            }
         }
         
         reader.close();
         
       
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   return data;
}
            public void UpdateorderStaff(int orderId,String staff) {
      try {
         BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
         String line;
         Order a;
         boolean found = false;
         
         while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(DELIMITER);
            
            if (Integer.parseInt(tokens[0]) == orderId) {
               found = true;
               a=new Order(Integer.parseInt(tokens[0]),Integer.parseInt(tokens[1]),tokens[2],(int)Double.parseDouble(tokens[3]),tokens[4],tokens[5]);
               this.updateOrder(a.getOrderId(), a.getCustomerId(), a.getItemName(), a.getPrice(), "Paid",staff);
           
            }
         }
         
         reader.close();
         
         if (!found) {
    JOptionPane.showMessageDialog(null, "Order Not Found");
         }
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   }
            
   public void UpdateorderStatusbystaff(int orderId,String status,String staff) {
      try {
         BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
         String line;
         Order a;
         boolean found = false;
         
         while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(DELIMITER);
            
            if (Integer.parseInt(tokens[0]) == orderId) {
               found = true;
               a=new Order(Integer.parseInt(tokens[0]),Integer.parseInt(tokens[1]),tokens[2],(int)Double.parseDouble(tokens[3]),tokens[4],tokens[5]);
               this.updateOrder(a.getOrderId(), a.getCustomerId(), a.getItemName(), a.getPrice(), status,staff);
           
            }
         }
         
         reader.close();
         
         if (!found) {
    JOptionPane.showMessageDialog(null, "Order Not Found");
         }
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   }         

           public ArrayList<String> fetchAllNA_() {
               ArrayList<String> data = new ArrayList<String>();
          try {
         BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
         String line;
         String d = "";
         
         while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(DELIMITER);
           
            if("NA".equals(tokens[5])||"na".equals(tokens[5])){
               d+=tokens[0]+" \t";
               d+=tokens[1]+" \t";
               d+=tokens[2]+" \t";
               d+=tokens[3]+" \t";
               d+=tokens[4]+" \t";
               d+=tokens[5]+" \n";
               
               data.add(d);
               d="";
              
            }
         }
         
         reader.close();
         
       
      } catch (IOException e) {
         System.out.println("Error: " + e.getMessage());
      }
   return data;
}

}